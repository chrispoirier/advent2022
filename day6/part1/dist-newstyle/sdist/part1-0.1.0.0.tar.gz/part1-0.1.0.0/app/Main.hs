module Main where

import Control.Exception
import Data.List.Split
import Paths_part1

main :: IO ()
main = 
    do  inputContents <- readInputFile("test")
        --putStrLn inputContents
        putStrLn findSOP(inputContents)        

readInputFile :: String -> IO String
readInputFile name =
    handle(\(SomeException e) -> error("Error reading file:"++ name ++"\n"++ displayException e)) 
        (do filePath <- getDataFileName name
            readFile filePath
        )

findSOP :: String -> Int
findSOP contents = 
    case 