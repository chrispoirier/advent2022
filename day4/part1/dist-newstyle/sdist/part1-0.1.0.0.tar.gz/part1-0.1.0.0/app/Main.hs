module Main where

import Control.Exception
import Paths_part1

main :: IO ()
main = 
    do  inputContents <- readInputFile("test")
        --putStrLn inputContents
        rangePairs <- splitRanges(inputContents)

readInputFile :: String -> IO String
readInputFile name =
    do  handle(\(SomeException e) -> error("Error reading file:"++ name ++"\n"++ displayException e)) 
            (do filePath <- getDataFileName name
                readFile filePath
            )

splitRanges :: String -> [[int]]
splitRanges contents = 
    do  